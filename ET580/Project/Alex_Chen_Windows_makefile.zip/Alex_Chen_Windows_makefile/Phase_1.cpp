// (c) s. trowbridge 2021
#include <iostream>

#include "Flight.h"

int main() {
    std::cout << "\n";

    Airline();
    Airport();
    Passenger();
    Pilot();
    Flight();

    std::cout << "PHASE 1 COMPLETED **************************************\n\n";

    std::cout << "\n";
    return 0;
}
