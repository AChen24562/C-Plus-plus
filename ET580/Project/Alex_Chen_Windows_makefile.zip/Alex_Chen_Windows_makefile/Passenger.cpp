#include "Passenger.h"
Passenger::Passenger():Passenger("NoName"){}
Passenger::Passenger(std:: string n):Person(n){}
