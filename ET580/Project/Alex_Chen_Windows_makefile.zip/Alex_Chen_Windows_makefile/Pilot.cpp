#include "Pilot.h"
Pilot::Pilot():Pilot("NoName"){}
Pilot::Pilot(std:: string n): Person(n){}
