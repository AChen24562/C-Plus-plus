// s. trowbridge 2020
#include <iostream>
using namespace std;

void countdown(int n) {
}

int main() {
    cout << endl;

    countdown(10);

    cout << endl;
    return 0;
}
