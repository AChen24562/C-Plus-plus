// s. trowbridge 2020
#include <iostream>
using namespace std;

int sumDigits(long n) {
}

int main() {
    cout << endl;

    long x;
    cout << "Enter a positive integer of at least three digits: ";
    cin >> x;

    cout << sumDigits(x) << endl;

    cout << endl;
    return 0;
}
