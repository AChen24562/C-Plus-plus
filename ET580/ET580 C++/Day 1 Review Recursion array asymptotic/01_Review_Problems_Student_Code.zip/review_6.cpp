// s. trowbridge 2020
#include <iostream>
using namespace std;

void insertAt(int *a, const int &CAPACITY, int &size, int value, int index) {
}
void print(int *a, const int &SIZE) {
}

int main() {
    cout << endl;

    const int CAPACITY = 100;
    int a[CAPACITY] = {10,20,30,40,50,60,70,80,90,100};
    int size = 10;

    print(a, size);
    insertAt(a, CAPACITY, size, 5, 0);
    print(a, size);
    insertAt(a, CAPACITY, size, 150, 11);
    print(a, size);
    insertAt(a, CAPACITY, size, 55, 6);
    print(a, size);

    cout << endl;
    return 0;
}
