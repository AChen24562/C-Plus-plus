// s. trowbridge 2020
#include <iostream>
#include <time.h>
using namespace std;

void randomize(int a[], const int &SIZE) {
}
void print(const int a[], const int &SIZE) {
}

int main() {
    cout << endl;
    srand(time(NULL));

    const int SIZE = 10;
    int a[SIZE];

    randomize(a, SIZE);
    print(a, SIZE);

    cout << endl;
    return 0;
}
