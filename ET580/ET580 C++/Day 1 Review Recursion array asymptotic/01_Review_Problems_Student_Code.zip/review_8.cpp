// s. trowbridge 2020
#include <iostream>
using namespace std;

void print(const int a[], const int &SIZE) {
}

int main() {
    cout << endl;

    const int SIZE = 4;
    int a[SIZE];

    cout << "Enter 4 column values (from 0 to 3): ";
    for(int i=0; i<SIZE; i++) {
        cin >> a[i];
    }

    print(a, SIZE);

    cout << endl;
    return 0;
}
