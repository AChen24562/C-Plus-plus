// s. trowbridge 2020
#include <iostream>
using namespace std;

void printIter(const int a[], const int &SIZE) {
}
void printRec(const int a[], int size) {
}

int main() {
    cout << endl;

    const int SIZE = 5;
    int a[SIZE] = {1, 2, 3, 4, 5};

    printIter(a, SIZE);
    cout << endl;
    printRec(a, SIZE);

    cout << endl;
    return 0;
}
