// s. trowbridge 2020
#include <iostream>
using namespace std;

void append(int *a, const int &CAPACITY, int &size, int value) {
}

void print(int *a, const int &SIZE) {
}

int main() {
    cout << endl;

    const int CAPACITY = 10;
    int a[CAPACITY] = {10,20,30,40,50,60,70,80};
    int size = 8;

    print(a, size);
    append(a, CAPACITY, size, 90);
    print(a, size);
    append(a, CAPACITY, size, 95);
    print(a, size);
    append(a, CAPACITY, size, 100); // should not append, why?
    print(a, size);

    cout << endl;
    return 0;
}
