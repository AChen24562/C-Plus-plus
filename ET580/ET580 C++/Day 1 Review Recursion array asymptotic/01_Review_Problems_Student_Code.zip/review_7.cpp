// s. trowbridge 2020
#include <iostream>
using namespace std;

void sortedInsert(int *a, const int &CAPACITY, int &size, int value) {
}

void print(const int a[], const int &SIZE) {
}

int main() {
    cout << endl;

    const int CAPACITY = 100;
    int a[CAPACITY] = {10,20,30,40,50,60,70,80,90,100};
    int size = 10;

    print(a, size);
    sortedInsert(a, CAPACITY, size, 5);
    print(a, size);
    sortedInsert(a, CAPACITY, size, 150);
    print(a, size);
    sortedInsert(a, CAPACITY, size, 55);
    print(a, size);

    cout << endl;
    return 0;
}
